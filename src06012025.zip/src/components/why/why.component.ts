import { Component } from '@angular/core';

@Component({
  selector: 'app-why',
  standalone: true,
  imports: [],
  templateUrl: './why.component.html',
  styleUrl: './why.component.scss'
})
export class WhyComponent {

}
